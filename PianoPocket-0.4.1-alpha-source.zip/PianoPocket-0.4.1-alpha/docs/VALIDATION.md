# Validation — 2026-10-12

## 実行環境

Linux x86-64クラウド環境。Android SDK 36 / Build Tools 36.0.0、NDK 28.2.13676358、CMake 3.22.1、Gradle 8.13、AGP 8.10.1、Temurin JDK 17.0.20.1、Oboe 1.9.3。ホストC++コンパイラはGCC 14.2。Android端末は `adb devices` で0台。エミュレーターも未実行。

## 結果

| チェック | 結果 |
| --- | --- |
| `./gradlew assembleDebug testDebugUnitTest lintDebug` | PASS。ARM64デバッグAPK生成。Lint errors 0 |
| JVM parser / MIDI tests | 10件PASS。XML継承・volume乗算・effect順・binding・release / pedal・未知XML警告・危険パス・DTD拒否・不正range・fragmentation / running status / SysEx |
| JVM ZIP tests | 9件PASS（macOS sidecar除外を追加）。有効ZIP、traversal、absolute path、canonical duplicate、per-file size、total size、file count、compression bomb |
| JVM velocity / tags / menu tests | 3件PASS。合計JVM 22件PASS |
| Release native test suite | PASS。decoder、非同期cache、発音、velocity、sustain、release、自然終了後のrelease、同音FIFO、channel分離、voice stealing、limiter、event overflow、FFT convolution、reverb tail |
| Audio-thread allocation instrumentation | テストしたrender / effect経路の `operator new/new[]` 呼び出し0件。OS内部の挙動や全入力を証明するものではない |
| AddressSanitizer / UndefinedBehaviorSanitizer | native suite PASS、リーク・メモリ境界・未定義動作の指摘なし |
| APK signature | apksigner verify PASS。debug v2署名 |
| ZIP page alignment | `zipalign -c -P 16 4` PASS |
| APK内ELFのLOAD alignment | libpianopocket / libc++_shared / androidx.graphics.path全て `0x4000` |
| 自作fixture生成と監査 | PASS、4 velocity層 / release / pedalを含むZIPとJSON report生成 |
| Helsinki v1.6実音源 | 344 WAVデコード、5プリセット×1320ケースPASS。3秒paced streaming各cache miss=0、I/O errors=0。6番目は配布XMLの余分な終了タグで拒否 |
| 純正IR | 5種の完全delta response、誤差0.0002以内・256 framesの処理遅延を確認 |
| 本番ZIPインポーター | 全2073 entries / 1.53GBを安全展開、実プリセット6件を登録対象として検出 |
| Galaxy S26 / Android 16 | 未接続。起動、発音、タッチ、USB / BLE MIDI未検証 |
| Windows VST3 | Wine / Box64未導入。host起動・pluginロード・MIDI / audio・遅延未検証 |

Lintには依存の新版案内、ARM64のみであることに関するChromeOS案内、API世代・ストレージ容量API等の警告が残っています。エラーを抑制するbaselineは使用していません。

## 0.1.0時点のホスト合成ベンチマーク（参考）

256 frames、48kHz、常駐の自作stereo sample、100 blocks平均。レイテンシ測定ではありません。ストリーミングやHelsinkiの5マイク／IR負荷は含まず、Galaxy S26の性能を表すものではありません。

| Sample voices | 平均ブロック処理時間 |
| --- | --- |
| 32 | 52.75 µs |
| 80 | 126.30 µs |
| 128 | 202.33 µs |

## 要求された完成条件の扱い

1〜8と10のためのAndroidコードは実装し、ビルド・ホストテストで検証しました。ただし「Androidで起動する」「実際に鍵盤／MIDIで鳴る」「再起動後に利用できる」を**実機成功として報告していません**。SAFとライブラリ保存、Android MIDIハードウェア、音声経路は実機試験が必要です。条件9は実ファイルの構造・デコード・ホスト発音を検証し、[結果と残る互換性差](HELSINKI.md)を記録しました。純正との音響比較と実機試験は未実施です。全条件を達成した完成品ではありません。

## 再現コマンド

```sh
./gradlew assembleDebug testDebugUnitTest lintDebug
cmake -S native -B build/native -DCMAKE_BUILD_TYPE=Release
cmake --build build/native -j 4
ctest --test-dir build/native --output-on-failure
cmake -S native -B build/sanitized -DCMAKE_BUILD_TYPE=Debug \
  -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -fno-omit-frame-pointer' \
  -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build/sanitized -j 4
ASAN_OPTIONS=detect_leaks=1 ctest --test-dir build/sanitized --output-on-failure
apksigner verify --verbose app/build/outputs/apk/debug/app-debug.apk
zipalign -c -P 16 4 app/build/outputs/apk/debug/app-debug.apk
```

## 0.2.0の追加検証

voice-scope table、tagミキサー、CC64のnote 1 / 2マッピング、整数小数frame、IRメニュー、+12dB gain、256/2048 hybrid FFTを追加。ASan/UBSanのnative suiteと実XFマッピングprobeを通過。実サンプルはCIに置かず、利用者が指定するprivateディレクトリから検証します。詳細と再現コマンドは[HELSINKI.md](HELSINKI.md)。

## GitHub公開後のCI状態

main / v0.2.0-alphaのプッシュは成功しました。GitHub Actionsの初回実行は `The job was not started because your account is locked due to a billing issue.` というGitHub側の理由でジョブ開始前に停止しています。ローカルのビルド・テスト成功をホステッドCI成功とは扱いません。[実行記録](https://github.com/tstyr/PianoPocket/actions/runs/38220736938)。本体の不具合ではなく、GitHubアカウント側で解消が必要です。

Release Assetsへの通常添付も試行しました。CLIからの直接添付は `uploads.github.com` がHTTP 401を返します。代替として `.github/workflows/attach-release.yml` を追加し、固定した配布コミットから検証済みAPK等を取得・SHA-256確認して既存リリースへ添付する手動実行処理を用意しました。YAML・Bash・Python構文チェックはPASSですが、[添付処理の実行](https://github.com/tstyr/PianoPocket/actions/runs/38222693297)も同じbilling lockで開始前に停止しました。Assets添付の成功とは扱いません。Actionsを使わない方法として、リポジトリ所有者は[リリース編集画面](https://github.com/tstyr/PianoPocket/releases/edit/v0.2.0-alpha)から配布済みAPKを手動で添付できます。


## 0.3.0 MIDI / recording / export

MIDI拡張の[詳細・手動検証手順](SEQUENCER.md)を追加。JVMは36件（新規14件）、native / ASan / UBSan、6 WAV形式／レート組合せ、Helsinki XFの実サンプル＋IRによる10秒書き出しがPASS。書き出しではIR mixを0.35に明示変更して残響を検査し、サンプルcache miss / I/O errorは0。Galaxy S26やエミュレーターは未接続のため、ロールUI・SAF保存・USB/BLE録音・レイテンシの実機成功は未確認です。

0.3のmain / tag / release-artifactsブランチをプッシュ済み。Assets直接アップロードは再びHTTP 401となったため、配布用ブランチへAPK・ZIP・自作MIDIを保存してリリース本文からリンク。公開されたAPKを再取得しSHA-256一致を確認。Actionsの新しい実行は行っておらず、先のbilling lockをCI成功として扱いません。


## 0.3.1 reverb clipping

利用者のSchool Hall / Mix 0.71の音割れを実データで再現。IR音量補正と固定メモリの先読みリミッターを実装し、実IR5種×4 mix×3発音密度の60ケース、低周波／1kHzの高調波検査、native / ASan / UBSan、36 JVM tests、ビルド／Lintを通過。[原因・検査・実機確認手順](REVERB_FIX.md)。利用者端末での起動と演奏の報告・画面は得ていますが、修正版の聴感・実測レイテンシは開発環境で実機確認していません。

0.3.1のmain / tag / release-artifactsブランチとリリースを公開済み。Assets直接添付はHTTP 401が継続し未完了。公開ブランチから修正版APKを再取得してSHA-256一致を確認しました。新しいActions実行は行っていません。

## 0.4 performance UI

横画面優先・全画面ロール、48dpアイコン操作と長押し説明、3本ずつ並ぶ実XMLマイクフェーダー、鍵盤を保持する音源パネルを実装。MIDI選択済みのライブラリで回転時に勝手に戻る可能性を修正。ドレミ設定・録音・WAV/MIDI書き出しを維持。[操作と実機検証項目](PERFORMANCE_UI.md)。

`assembleDebug testDebugUnitTest lintDebug` PASS、JUnit 36 / failures 0 / errors 0 / skipped 0、Lint errors 0。native suite PASS。今回はUI変更で、DSPコードに変更はなく、0.3.1の60ケース・ASan / UBSan実音源検証を再実行したとは扱いません。

APK versionCode 5 / versionName 0.4.0-alpha / ARM64 / min29 / target36。v2署名PASS、zipalign 16KiB PASS、3つのELFのLOAD整列が16384。旧版と同じ証明書SHA-256 `d2b4e0c9de24c4a5ec51e6e05651e526aee3da3e3a720f756c2027789b132761`。APK SHA-256 `b0e177b3b0f209e717b66a2ed59060dca7337f43ca16a31de0ea3a9bd5eef027`、27481758 bytes。開発環境の実機・エミュレーターは未接続で、スクリーンショット・UI操作・Galaxy S26での更新成功を検証済みとは主張しません。

0.4.0のmain / tag / release-artifactsとプリリリースを公開済み。Assets直接添付は今回もHTTP 401で未完了。公開先から27481758 bytesのAPKを再取得し、上記SHA-256と一致しました。ソース・検証ZIP・checksum一覧も公開先から取得可能と確認。新しいActions実行は行っておらず、既存billing lockの解消やホステッドCI成功を主張しません。

## 0.4.1 sustain / labels / compressed audio

ロールはkeyEndまでを表示し、発音end・MIDI CC64は維持。チャンネル別ペダルのSUS表示とドレミの縦配置を追加。FLAC24 / LAME MP3 / Android AAC-LC M4Aの実エンコードを実装。[書き出しと実機確認手順](EXPORT_FORMATS.md)。

- `assembleDebug testDebugUnitTest lintDebug assembleDebugAndroidTest` PASS。JUnit 41 / failures 0 / errors 0 / skipped 0、Lint errors 0。native suite PASS。
- 44.1 / 48 kHz × 入力PCM16 / PCM24でFLAC4ケースとMP3 4bitrates16ケースを独立したFFmpegで復号。FLACはバイト一致、MP3は全フレーム数一致・左右の波形相関0.99超。キャンセル時の途中ファイル削除PASS。
- C/C++ともASan / UBSanを有効化し、native suiteと20 codec round tripsを通過。LAME upstreamのbit mask / scale / bit packingの符号付きシフトのUBを修正して再実行。Helsinki実演奏PCMの5 codecs（FLAC+4MP3）もASan / UBSanで通過。
- Helsinki XFの実サンプル・IRによる10秒、480000frames、PCM24書き出し。FLACは全PCM一致、MP3は各480000framesを復号。音声・原XML・IRは公開しない。前段のSampler/Effectsのアルゴリズムは変更していません。
- APK versionCode6 / versionName0.4.1-alpha / ARM64 / min29 / target36。署名v2・zipalign16KiB PASS。4 ELFのLOAD alignment>=16384、新しいlibmp3lame.soと実ライセンス本文assetを確認。旧版と同じ証明書。APK 28589208 bytes / SHA-256 `1605ef1417621c60c563632d55b40afa08596ecd5d3ed65a0e14a34e67dd6bf7`。
- `AacExporterDeviceTest` 2 testsとAndroid test APKを用意しビルド。端末未接続なので実行せず、M4Aの出力成功を検証済みとは主張しない。新ドレミ・SUSの表示、SAF保存、USB/BLE連動の実機試験も未実施。
